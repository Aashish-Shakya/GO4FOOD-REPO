package com.go4food;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Go4FoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
