//package com.go4food.repository;
//import org.springframework.stereotype.Repository;
//
//import com.go4food.entity.Dish;
//
//import org.springframework.data.jpa.repository.JpaRepository;
// 
// 
//  
//@Repository
//public interface DishRepository extends JpaRepository<Dish, Long>{
//
//} 