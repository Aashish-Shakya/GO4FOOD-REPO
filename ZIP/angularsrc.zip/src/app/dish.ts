export class Dish {
    id: number;
    name: string;
    price: number ;
    discount: number;
    image_url: string;
    category: string;
    visibility: string;

constructor(id:number,name:string,price:number,discount:number,image_url:string,category:string, visibility: string){
    this.id=id;
    this.name=name;
    this.price=price;
    this.discount=discount;
    this.image_url=image_url;
    this.category=category;
    this.visibility = visibility;
}


    //     private id:  number;
    //     private String name;
    //     private Double price;
    //     private Double discount = 0.0;
    //     private String image_url;
    //     private String category;
        
        
        
        
    //     public Dish() {
    //         super();
    //         // TODO Auto-generated constructor stub
    //     }
    
    
    
    //     public Dish(int id, String name, Double price, Double discount, String image_url, String category) {
    //         super();
    //         this.id = id;
    //         this.name = name;
    //         this.price = price;
    //         this.discount = discount;
    //         this.image_url = image_url;
    //         this.category = category;
    //     }
    
        
    
    //     public Dish(String name, Double price, Double discount, String image_url, String category) {
    //         super();
    //         this.name = name;
    //         this.price = price;
    //         this.discount = discount;
    //         this.image_url = image_url;
    //         this.category = category;
    //     }
    
    
    
    //     public Dish(int id, String name, Double price, String image_url, String category) {
    //         super();
    //         this.id = id;
    //         this.name = name;
    //         this.price = price;
    //         this.image_url = image_url;
    //         this.category = category;
    //     }
    
    
    
    //     public int getId() {
    //         return id;
    //     }
    
    
    
    //     public String getName() {
    //         return name;
    //     }
    
    
    
    //     public Double getPrice() {
    //         return price;
    //     }
    
    
    
    //     public Double getDiscount() {
    //         return discount;
    //     }
    
    
    
    //     public String getImage_url() {
    //         return image_url;
    //     }
    
    
    
    //     public String getCategory() {
    //         return category;
    //     }
    
    
    
        
        
        
    // }
    

}
