import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BootstrapModalsComponent } from './bootstrap-modals.component';

describe('BootstrapModalsComponent', () => {
  let component: BootstrapModalsComponent;
  let fixture: ComponentFixture<BootstrapModalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BootstrapModalsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BootstrapModalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
